public class Ejercicios {
	
	//Devuelve el valor almacenado en el indice posicion
	static int obtenerValor(int arreglo[], int posicion)
	{
		return arreglo[posicion];
	}
	
	//Devuelve el valor almacenado en el indice posicion
	static String obtenerValor(String arreglo[], int posicion)
	{
		return arreglo[posicion];
	}
	
	//Devuelve la suma de todos los elementos del arreglo
	static int obtenerSuma(int arreglo[])
	{
		int suma=0;
		for(int con=0;con<arreglo.length;c++){
			suma=suma+arreglo[con];
		}
		return suma;
	}
	
	//Devuelve el promedio de todos los elementos del arreglo
	static int obtenerPromedio(int arreglo[])
	{
		int suma=0;
		int pro=0;
		int con2=0;
		for(int con=0;con<arreglo.length;c++){
			suma=suma+arreglo[con];
			con2++;
		}
		return pro=suma/con2;	
	}
	
	//Devuelve true si valor esta 
	static boolean existe(char arreglo[], char valor)
	{
		for(int con=0;con<arreglo.length;con++){
			if(arreglo[con]==valor){
				return true;
				break;
			}
		}
		return false;
	}
		
	//Devuelve true si valor esta 
	static boolean existe(String arreglo[], String valor)
	{
		for(int con=0;con<arreglo.length;con++){
			if(arreglo[con].equalsIgnoreCase(valor)){
				return true;
				break;
			}
		}
		return false;
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
